package prog2.model;

import static java.lang.Math.min;
import prog2.vista.CentralUBException;
import java.util.ArrayList;
import java.util.Iterator;
import java.io.Serializable;

/**
 * Esta clase representa el sistema de refrigeración de la central eléctrica.
 * Implementa la interfaz InComponent.
 * Implementa la interfaz Serializable para permitir su serialización.
 * 
 * @author Yasmina Dermouh y Katerina Lothe
 */
public class SistemaRefrigeracio implements InComponent, Serializable {
    
    // Atributos del sistema de refrigeración
    private ArrayList <BombaRefrigerant> bombes;
    private boolean activat;
    private VariableUniforme variable ;
    
    /**
     * Constructor de la clase SistemaRefrigeracio.
     * Inicializa la lista de bombas y la variable uniforme.
     */
    public SistemaRefrigeracio() {
        this.bombes = new ArrayList<>();
        this.variable = new VariableUniforme(123);
    }
    
    /**
     * Retorna la lista de bombas del sistema de refrigeración.
     * 
     * @return la lista de bombas.
     */
    public ArrayList<BombaRefrigerant> getListaBombas() {
        return bombes;
    }
    
    /**
     * Activa una bomba específica en el sistema de refrigeración.
     * 
     * @param id el identificador de la bomba a activar.
     * @throws CentralUBException si la bomba está fuera de servicio.
     */
    public void activaBomba(int id) throws CentralUBException {
        Iterator<BombaRefrigerant> itr = bombes.iterator();
        while(itr.hasNext()){
            BombaRefrigerant bombaActual = itr.next();
            if(bombaActual.getId() == id)
                bombaActual.activa();
        }
    }
    
    /**
     * Desactiva una bomba específica en el sistema de refrigeración.
     * 
     * @param id el identificador de la bomba a desactivar.
     */
    public void desactivaBomba(int id) {
        Iterator<BombaRefrigerant> itr = bombes.iterator();
        while(itr.hasNext()){
            BombaRefrigerant bombaActual = itr.next();
            if(bombaActual.getId() == id)
                bombaActual.desactiva();
        }
    }
    
    /**
     * Activa el sistema de refrigeración.
     * 
     * @throws CentralUBException si todas las bombas están fuera de servicio.
     */
    @Override
    public void activa() throws CentralUBException {
        boolean anyBombActivated = false;
        Iterator<BombaRefrigerant> itr = bombes.iterator();
        while(itr.hasNext()){
            BombaRefrigerant currentBomba = itr.next();
            if(!currentBomba.getForaDeServei()){
                currentBomba.activa();
                anyBombActivated = true;
            }
        }
        if (!anyBombActivated) {
            throw new CentralUBException("Error: Todas las bombas refrigerantes están fuera de servicio.");
        }
        this.activat = true;
    }

    /**
     * Desactiva el sistema de refrigeración.
     */
    @Override
    public void desactiva() {
       Iterator<BombaRefrigerant> itr = bombes.iterator();
        while(itr.hasNext()){
            BombaRefrigerant currentBomba = itr.next();
            if(currentBomba.getActivat())
                currentBomba.desactiva();
        }
       this.activat = false;
    }
   
    /**
     * Añade una bomba al sistema de refrigeración.
     * 
     * @param bomba la bomba a añadir.
     */
    public void afegirBomba(BombaRefrigerant bomba) { 
        bombes.add(bomba);
    } 
    
    /**
     * Revisa las incidencias del sistema de refrigeración y las registra en la página de incidencias.
     * Además, actualiza el servicio de las bombas.
     * 
     * @param p la página de incidencias en la que se registrarán las incidencias.
     */
    @Override
    public void revisa(PaginaIncidencies p) {
        Iterator<BombaRefrigerant> itr = bombes.iterator();
        while(itr.hasNext()){
            BombaRefrigerant bombaActual = itr.next();
            bombaActual.revisa(p);
            bombaActual.setServei(variable);
        }  
    }
    
    /**
     * Retorna el costo operativo del sistema de refrigeración.
     * 
     * @return el costo operativo del sistema de refrigeración.
     */
    @Override
    public float getCostOperatiu() {
        int numBombesActives = 0;
        Iterator<BombaRefrigerant> itr = bombes.iterator();
        while(itr.hasNext()){ 
            BombaRefrigerant bombaActual = itr.next();
            if(bombaActual.getActivat()) numBombesActives++;
        }
        return 125 * numBombesActives;  
    }
    
    /**
     * Calcula el output del sistema de refrigeración basado en la entrada.
     * 
     * @param input el valor de entrada.
     * @return el output del sistema de refrigeración.
     */
    @Override
    public float calculaOutput(float input) {
        int numBombesActives = 0;
        for(BombaRefrigerant bomba: bombes) {
            if(bomba.getActivat()) numBombesActives++;
        }
        return min(input, 250 * numBombesActives);
    }
    
    /**
     * Retorna una representación en String del sistema de refrigeración.
     * 
     * @return una representación en String del sistema de refrigeración.
     */
    @Override
    public String toString() {
        String result = "";
        if(!bombes.isEmpty()){
            for(BombaRefrigerant bomba: bombes) {
                result += bomba.toString() + "\n";
            }
        }
        return result;
    }
}
