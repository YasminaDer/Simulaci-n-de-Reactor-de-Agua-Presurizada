/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package prog2.model;

import prog2.vista.CentralUBException;
import java.io.*;

/**
 * Esta clase representa una bomba de refrigeración que puede ser activada o desactivada
 * y que puede encontrarse fuera de servicio.
 * Implementa la interfaz InBombaRefrigerant y es serializable.
 * 
 * @autor Katerina Lothe y Yasmina Dermouh
 */

public class BombaRefrigerant implements InBombaRefrigerant, Serializable {
    
    private final int id;
    private boolean activat;
    private boolean servei;
    
    /**
     * Constructor de la clase BombaRefrigerant.
     * Inicializa una nueva bomba de refrigeración con el id especificado y establece su estado de servicio.
     * 
     * @param variable una instancia de VariableUniforme para determinar el estado de servicio.
     * @param id el identificador único de la bomba.
     */
    public BombaRefrigerant(VariableUniforme variable, int id) {
        this.id = id;
        this.setServei(variable);
        this.activat = false;
    }
    
    /**
     * Obtiene el identificador de la bomba de refrigeración.
     * 
     * @return el identificador de la bomba.
     */
    @Override
    public int getId() {
        return this.id;
    }
    
    /**
     * Establece el estado de servicio de la bomba de refrigeración en función de una VariableUniforme.
     * 
     * @param v una instancia de VariableUniforme para determinar el estado de servicio.
     */
    public void setServei(VariableUniforme v) {
        servei = v.seguentValor() >= 20;
    }
    
    /**
     * Activa la bomba de refrigeración si no se encuentra fuera de servicio.
     * 
     * @throws CentralUBException si la bomba se encuentra fuera de servicio.
     */
    @Override
    public void activa() throws CentralUBException {
        if(getForaDeServei()) {
            throw new CentralUBException("Error: La bomba se encuentra fuera de servicio.");
        } else {
            this.activat = true;
        }
    }
    
    /**
     * Desactiva la bomba de refrigeración.
     */
    @Override
    public void desactiva() {
        this.activat = false;
    }
    
    /**
     * Retorna el estado de activación de la bomba de refrigeración.
     * 
     * @return true si la bomba está activada, false en caso contrario.
     */
    @Override
    public boolean getActivat() {
        return this.activat;
    }
    
    /**
     * Retorna si la bomba de refrigeración se encuentra fuera de servicio.
     * 
     * @return true si la bomba está fuera de servicio, false en caso contrario.
     */
    @Override
    public boolean getForaDeServei() {
        return !servei;
    }
    
    /**
     * Revisa la bomba de refrigeración para detectar incidencias y registrarlas en una página de incidencias.
     * 
     * @param p la página de incidencias donde se registrarán las incidencias detectadas.
     */
    @Override
    public void revisa(PaginaIncidencies p) {
        if(getForaDeServei()) {
            desactiva();
            String descIncidencia = "La bomba refrig. " + this.getId() + " se encuentra fuera de servicio.";
            p.afegeixIncidencia(descIncidencia);
        }    
    }
    
    /**
     * Retorna una representación en forma de cadena de la bomba de refrigeración.
     * 
     * @return una cadena con el estado de la bomba de refrigeración.
     */
    @Override
    public String toString() {
        return "Id = " + this.getId() + ", Activado = " + (this.getActivat() ? "Sí" : "No") + ", Fuera de servicio " + (this.getForaDeServei() ? "Sí" : "No");
    }
}
