/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package prog2.model;

import java.io.Serializable;

/**
 * Esta clase representa una página económica en el sistema de la central eléctrica,
 * extendiendo la funcionalidad de la clase PaginaBitacola.
 * Implementa la interfaz Serializable para permitir su serialización.
 * 
 * @autor Yasmina Dermouh y Katerina Lothe
 */
public class PaginaEconomica extends PaginaBitacola implements Serializable {

    // Beneficios obtenidos en el día
    private float beneficis;
    // Penalización por exceso de producción en el día
    private float penalitzacio;
    // Coste operativo del día
    private float costOperatiu;
    // Ganancias acumuladas hasta el día
    private float guanysAcumulats;

    /**
     * Constructor de la clase PaginaEconomica.
     * 
     * @param dia el día correspondiente a la página económica.
     * @param beneficis los beneficios obtenidos en el día.
     * @param penalitzacio la penalización por exceso de producción en el día.
     * @param costOperatiu el coste operativo del día.
     * @param guanysAcumulats las ganancias acumuladas hasta el día.
     */
    public PaginaEconomica(int dia, float beneficis, float penalitzacio, float costOperatiu, float guanysAcumulats) {
        super(dia);
        this.beneficis = beneficis;
        this.penalitzacio = penalitzacio;
        this.costOperatiu = costOperatiu;
        this.guanysAcumulats = guanysAcumulats;
    }

    /**
     * Retorna una representación en String de la página económica.
     * 
     * @return una cadena de texto que representa la página económica.
     */
    @Override
    public String toString() {
        return "# Página Económica" + "\n" +
                "- Día: " + dia + "\n" +
                "- Beneficios: " + beneficis + " Unidades Económicas" + "\n" +
                "- Penalización Exceso Producción: " + penalitzacio + " Unidades Económicas" + "\n" +
                "- Coste Operativo: " + costOperatiu + " Unidades Económicas" + "\n" +
                "- Ganancias acumuladas: " + guanysAcumulats + " Unidades Económicas" + "\n";
    }
}
