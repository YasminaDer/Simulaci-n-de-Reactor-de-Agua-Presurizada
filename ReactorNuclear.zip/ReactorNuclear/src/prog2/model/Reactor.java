package prog2.model;

import prog2.vista.CentralUBException;
import java.io.Serializable;

/**
 * Esta clase representa el reactor en el sistema de la central eléctrica,
 * implementando la interfaz InComponent.
 * Implementa la interfaz Serializable para permitir su serialización.
 * 
 * @autor Yasmina Dermouh y Katerina Lothe
 */
public class Reactor implements InComponent, Serializable {
    
    // Atributos del reactor
    private float temp;
    private boolean activat;
    
    /**
     * Constructor de la clase Reactor.
     * Inicializa la temperatura del reactor en 30 grados y lo desactiva.
     */
    public Reactor(){
        this.temp = 30f;
        this.activat = false;
    }
    
    /**
     * Retorna el estado de activación del reactor.
     * 
     * @return true si el reactor está activado, false de lo contrario.
     */
    public boolean getActivat() {return activat;}
    
    /**
     * Retorna la temperatura actual del reactor.
     * 
     * @return la temperatura actual del reactor.
     */
    public float getTemp() { return temp; }
    
    /**
     * Establece la temperatura del reactor.
     * 
     * @param temp la temperatura a establecer.
     */
    public void setTemp(float temp) { this.temp = temp; }

    /**
     * Activa el reactor.
     * 
     * @throws CentralUBException si la temperatura del reactor supera los 1000 grados.
     */
    @Override
    public void activa() throws CentralUBException {
        if(temp > 1000) throw new CentralUBException("Error: la temperatura del reactor supera la máxima de 1.000 grados." );
        else 
            this.activat = true;
    }
    
    /**
     * Desactiva el reactor y restablece la temperatura a 30 grados.
     */
    @Override
    public void desactiva() { 
        this.activat = false;
        this.setTemp(30f);
    }

    /**
     * Revisa las incidencias del reactor y las registra en la página de incidencias.
     * Si la temperatura supera los 1000 grados, desactiva el reactor y registra la incidencia.
     * 
     * @param p la página de incidencias en la que se registrarán las incidencias.
     */
    @Override
    public void revisa(PaginaIncidencies p) {
        if(temp > 1000) {
            desactiva();
            String descIncidencia = "El reactor se desactivó por superar la temperatura máxima.";
            p.afegeixIncidencia(descIncidencia);
        }
    }
    
    /**
     * Retorna el costo operativo del reactor.
     * 
     * @return el costo operativo del reactor.
     */
    @Override
    public float getCostOperatiu() {return !activat ? 0: 30;}
    
    /**
     * Calcula el output del reactor basado en la temperatura y la entrada.
     * Si el reactor está desactivado, retorna la temperatura actual.
     * 
     * @param input el valor de entrada.
     * @return el output del reactor.
     */
    @Override
    public float calculaOutput(float input) {
        return !activat ? temp : temp + (100 - input) * 10;   
    }
}
