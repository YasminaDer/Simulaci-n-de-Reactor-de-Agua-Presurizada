/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package prog2.model;

import java.util.List;
import prog2.vista.CentralUBException;
import java.io.Serializable;
import java.util.ArrayList;

/**
 * Esta clase representa los datos y la lógica de la central eléctrica.
 * Implementa la interfaz InDades y es serializable.
 * 
 * @autor dortiz, Yasmina Dermouh y Katerina Lothe
 */
public class Dades implements InDades, Serializable {
    
    public final static long VAR_UNIF_SEED = 123;
    public final static float GUANYS_INICIALS = 0;
    public final static float PREU_UNITAT_POTENCIA = 1;
    public final static float PENALITZACIO_EXCES_POTENCIA = 200;
    
    private VariableUniforme variableUniforme;
    private float insercioBarres;
    private final Reactor reactor;
    private final SistemaRefrigeracio sistemaRefrigeracio;
    private final GeneradorVapor generadorVapor;
    private final Turbina turbina;
    private final Bitacola bitacola;
    private int dia;
    private float guanysAcumulats;
    
    /**
     * Constructor de la clase Dades.
     * Inicializa todos los componentes de la central y establece los valores iniciales.
     */
    public Dades() {
        this.variableUniforme = new VariableUniforme(VAR_UNIF_SEED);
        this.insercioBarres = 100f;
        this.reactor = new Reactor();
        this.sistemaRefrigeracio = new SistemaRefrigeracio();
        this.generadorVapor = new GeneradorVapor();
        this.generadorVapor.activa();
        this.turbina = new Turbina();
        this.turbina.activa();
        this.bitacola = new Bitacola();
        this.dia = 1;
        this.guanysAcumulats = GUANYS_INICIALS;
        
        // Añade bombas refrigerantes
        BombaRefrigerant b0 = new BombaRefrigerant(variableUniforme, 0);
        BombaRefrigerant b1 = new BombaRefrigerant(variableUniforme, 1);
        BombaRefrigerant b2 = new BombaRefrigerant(variableUniforme, 2);
        BombaRefrigerant b3 = new BombaRefrigerant(variableUniforme, 3);
        
        this.sistemaRefrigeracio.afegirBomba(b0);
        this.sistemaRefrigeracio.afegirBomba(b1);
        this.sistemaRefrigeracio.afegirBomba(b2);
        this.sistemaRefrigeracio.afegirBomba(b3);
    }
    
    /**
     * Obtiene el día actual del sistema.
     * 
     * @return el día actual.
     */
    public int getDia() {
        return dia;
    }
    
    /**
     * Obtiene el grado de inserción de barras del reactor.
     * 
     * @return el grado de inserción de barras.
     */
    @Override
    public float getInsercioBarres() {
        return insercioBarres;
    }
    
    /**
     * Obtiene las ganancias acumuladas hasta el momento.
     * 
     * @return las ganancias acumuladas.
     */
    public float getGuanysAcumulats() {
        return guanysAcumulats;
    }
    
    /**
     * Establece el grado de inserción de barras del reactor.
     * 
     * @param insercioBarres el nuevo grado de inserción de barras.
     * @throws CentralUBException si el valor está fuera del rango válido (0-100).
     */
    @Override
    public void setInsercioBarres(float insercioBarres) throws CentralUBException {
        if (insercioBarres <= 100f && insercioBarres >= 0f) {
            this.insercioBarres = insercioBarres;
        } else {
            throw new CentralUBException("Error: fuera del rango válido para el grado de inserción de barras.");
        }
    }
    
    /**
     * Activa el reactor.
     * 
     * @throws CentralUBException si ocurre un error al activar el reactor.
     */
    @Override
    public void activaReactor() throws CentralUBException {
        reactor.activa();
    }
    
    /**
     * Desactiva el reactor.
     */
    @Override
    public void desactivaReactor() {
        reactor.desactiva();
    }
    
    /**
     * Muestra el estado del reactor.
     * 
     * @return el reactor.
     */
    @Override
    public Reactor mostraReactor() {
        return reactor;
    }
    
    /**
     * Activa una bomba del sistema de refrigeración.
     * 
     * @param id el identificador de la bomba.
     * @throws CentralUBException si ocurre un error al activar la bomba.
     */
    @Override
    public void activaBomba(int id) throws CentralUBException {
        sistemaRefrigeracio.activaBomba(id);
    }
    
    /**
     * Desactiva una bomba del sistema de refrigeración.
     * 
     * @param id el identificador de la bomba.
     */
    @Override
    public void desactivaBomba(int id) {
        sistemaRefrigeracio.desactivaBomba(id);
    }
    
    /**
     * Muestra el estado del sistema de refrigeración.
     * 
     * @return el sistema de refrigeración.
     */
    @Override
    public SistemaRefrigeracio mostraSistemaRefrigeracio() {
        return sistemaRefrigeracio;
    }
    
    /**
     * Calcula la potencia generada por la central.
     * 
     * @return la potencia generada.
     */
    @Override
    public float calculaPotencia() {
        return turbina.calculaOutput(generadorVapor.calculaOutput(sistemaRefrigeracio.calculaOutput(reactor.calculaOutput(getInsercioBarres()))));
    }
    
    /**
     * Muestra el estado de la central en función de la demanda de potencia.
     * 
     * @param demandaPotencia la demanda de potencia actual.
     * @return una página de estado con la información actual de la central.
     */
    @Override
    public PaginaEstat mostraEstat(float demandaPotencia) {
        float outputReactor = reactor.calculaOutput(getInsercioBarres());
        float outputSistemaRefrig = sistemaRefrigeracio.calculaOutput(outputReactor);
        float outputGenerador = generadorVapor.calculaOutput(outputSistemaRefrig);
        float outputTurbina = turbina.calculaOutput(outputGenerador);
        return new PaginaEstat(dia, demandaPotencia, insercioBarres, outputReactor, outputSistemaRefrig, outputGenerador, outputTurbina);
    }
    
    /**
     * Muestra la bitácora de la central.
     * 
     * @return la bitácora.
     */
    @Override
    public Bitacola mostraBitacola() {
        return bitacola;
    }
    
    /**
     * Muestra las incidencias registradas en la bitácora.
     * 
     * @return una lista de páginas de incidencias.
     */
    @Override
    public List<PaginaIncidencies> mostraIncidencies() {
        return bitacola.getIncidencies();
    }
    
    /**
     * Actualiza la economía de la central. Genera una página económica a 
     * partir de la demanda de potencia actual. Esta página económica incluye 
     * beneficios, penalización por exceso de potencia, costos operativos y 
     * ganancias acumuladas.
     * 
     * @param demandaPotencia la demanda de potencia actual.
     * @return una página económica con la información actualizada.
     */
    private PaginaEconomica actualitzaEconomia(float demandaPotencia) {
        float beneficis = 0;
        float penalitzacio = 0;
        float costOperatiu = turbina.getCostOperatiu() + generadorVapor.getCostOperatiu() 
                + reactor.getCostOperatiu() + sistemaRefrigeracio.getCostOperatiu();
        float unitats = this.calculaPotencia() * PREU_UNITAT_POTENCIA;
        
        if (unitats <= demandaPotencia) {
            beneficis = unitats;
        } else {
            beneficis = demandaPotencia;
            penalitzacio = PENALITZACIO_EXCES_POTENCIA;
        }
        guanysAcumulats = guanysAcumulats - penalitzacio - costOperatiu + beneficis;
        return new PaginaEconomica(dia, beneficis, penalitzacio, costOperatiu, guanysAcumulats);
    }
    
    /**
     * Actualiza el estado de la central. El método debe establecer la nueva
     * temperatura del reactor y revisar los componentes de la central. Si
     * se encuentran incidencias, se deben registrar en la página de incidencias
     * que se proporciona como parámetro de entrada.
     * 
     * @param paginaIncidencies la página de incidencias donde se registrarán las incidencias detectadas.
     */
    public void actualitzaEstatCentral(PaginaIncidencies paginaIncidencies) {
        float temp = reactor.calculaOutput(getInsercioBarres()) - sistemaRefrigeracio.calculaOutput(reactor.calculaOutput(getInsercioBarres()));
        if (temp >= 30) {
            reactor.setTemp(temp);
        } else {
            reactor.setTemp(30);
        }
        reactor.revisa(paginaIncidencies);
        sistemaRefrigeracio.revisa(paginaIncidencies);
        generadorVapor.revisa(paginaIncidencies);
        turbina.revisa(paginaIncidencies);
    }
    
    /**
     * Finaliza el día de operación de la central. Actualiza la economía,
     * el estado de la central y registra las incidencias del día.
     * 
     * @param demandaPotencia la demanda de potencia actual.
     * @return una bitácora con las páginas de economía, estado e incidencias del día.
     */
    @Override
    public Bitacola finalitzaDia(float demandaPotencia) {
        // Actualiza economía
        PaginaEconomica paginaEconomica = actualitzaEconomia(demandaPotencia);
        
        // Genera página de estado
        PaginaEstat paginaEstat = mostraEstat(demandaPotencia);

        // Actualiza estado central y registra incidencias
        PaginaIncidencies paginaIncidencies = new PaginaIncidencies(dia);
        actualitzaEstatCentral(paginaIncidencies);
        
        // Incrementa día
        dia += 1;
        
        // Guarda páginas en bitácora
        bitacola.afegeixPagina(paginaEconomica);
        bitacola.afegeixPagina(paginaEstat);
        bitacola.afegeixPagina(paginaIncidencies);
        
        // Retorna páginas
        Bitacola bitacolaDia = new Bitacola();
        bitacolaDia.afegeixPagina(paginaEconomica);
        bitacolaDia.afegeixPagina(paginaEstat);
        bitacolaDia.afegeixPagina(paginaIncidencies);
        return bitacolaDia;
    }
}
