package prog2.model;

import java.io.Serializable;

/**
 * Esta clase representa una página de estado en el sistema de la central eléctrica,
 * extendiendo la funcionalidad de la clase PaginaBitacola.
 * Implementa la interfaz Serializable para permitir su serialización.
 * 
 * @autor Yasmina Dermouh y Katerina Lothe
 */
public class PaginaEstat extends PaginaBitacola implements Serializable {

    // Demanda de potencia para el día
    private float potenciaDemanada;
    // Grado de inserción de barras de control
    private float insercioBarres;
    // Temperatura de salida del reactor
    private float outputReactor;
    // Temperatura de salida del sistema de refrigeración
    private float outputSistemaRefrig;
    // Temperatura de salida del generador de vapor
    private float outputGenerador;
    // Unidades de potencia generadas por la turbina
    private float outputTurbina;
    // Porcentaje de demanda de potencia satisfecha
    private float potenciaSatisfeta;

    /**
     * Constructor de la clase PaginaEstat.
     * 
     * @param dia el día correspondiente a la página de estado.
     * @param potenciaDemanada la demanda de potencia para el día.
     * @param insercioBarres el grado de inserción de barras de control.
     * @param outputReactor la temperatura de salida del reactor.
     * @param outputSistemaRefrig la temperatura de salida del sistema de refrigeración.
     * @param outputGenerador la temperatura de salida del generador de vapor.
     * @param outputTurbina las unidades de potencia generadas por la turbina.
     */
    public PaginaEstat(int dia, float potenciaDemanada, float insercioBarres, float outputReactor, float outputSistemaRefrig, float outputGenerador, float outputTurbina) {
        super(dia);
        this.potenciaDemanada = potenciaDemanada;
        this.insercioBarres = insercioBarres;      
        this.outputReactor = outputReactor;
        this.outputSistemaRefrig = outputSistemaRefrig;
        this.outputGenerador = outputGenerador;
        this.outputTurbina = outputTurbina;
        this.potenciaSatisfeta = (outputTurbina / potenciaDemanada) * 100;
    }

    /**
     * Retorna una representación en String de la página de estado.
     * 
     * @return una cadena de texto que representa la página de estado.
     */
    @Override
    public String toString() {
        return "# Página de Estado\n" +
                "- Día: " + dia + "\n"+ 
                "- Demanda de potencia: " + potenciaDemanada + "\n" +
                "- Inserción de Barras: " + insercioBarres + "%\n" +
                "- Salida del Reactor: " + outputReactor + " Grados\n" +
                "- Salida del Sistema de Refrigeración: " + outputSistemaRefrig + " Grados\n" +
                "- Salida del Generador de Vapor: " + outputGenerador + " Grados\n" +
                "- Salida de la Turbina: " + outputTurbina + " Unidades de Potencia\n" +
                "- Demanda de Potencia Satisfecha: " + potenciaSatisfeta + "%\n";
    }
}
