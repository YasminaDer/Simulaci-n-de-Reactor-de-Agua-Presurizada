/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package prog2.model;
import java.io.Serializable;
/**
 * Esta clase representa un generador de vapor dentro de la central eléctrica.
 * Implementa la interfaz InComponent y es serializable.
 * 
 * @autor Yasmina Dermouh y Katerina Lothe
 */
public class GeneradorVapor implements InComponent, Serializable {
    
    private boolean activat;

    /**
     * Constructor de la clase GeneradorVapor.
     * Inicializa el generador de vapor como desactivado.
     */
    public GeneradorVapor() {
        this.activat = false;
    }
    
    /**
     * Obtiene el estado de activación del generador de vapor.
     * 
     * @return true si el generador de vapor está activado, false en caso contrario.
     */
    public boolean getActivat() {
        return activat;
    }
    
    /**
     * Activa el generador de vapor.
     */
    @Override
    public void activa() {
        this.activat = true;
    }

    /**
     * Desactiva el generador de vapor.
     */
    @Override
    public void desactiva() {
        this.activat = false;
    }

    /**
     * Revisa el generador de vapor y registra incidencias en la página de incidencias proporcionada.
     * Si el generador de vapor no está activado, se registra una incidencia.
     * 
     * @param p la página de incidencias donde se registrarán las incidencias detectadas.
     */
    @Override
    public void revisa(PaginaIncidencies p) {
        if (!activat) {
            String descIncidencia = "El generador de vapor no està habilitat.";
            p.afegeixIncidencia(descIncidencia);
        }
    }
    
    /**
     * Obtiene el costo operativo del generador de vapor.
     * 
     * @return el costo operativo del generador de vapor, que es 25 si está activado y 0 si está desactivado.
     */
    @Override
    public float getCostOperatiu() {
        return activat ? 25 : 0;
    }
    
    /**
     * Calcula la salida del generador de vapor en función de la entrada proporcionada.
     * Si el generador de vapor está desactivado, la salida es 0.
     * 
     * @param input la entrada al generador de vapor.
     * @return la salida del generador de vapor, que es el 80% de la entrada si está activado y 0 si está desactivado.
     */
    @Override
    public float calculaOutput(float input) {
        return !activat ? 0: (float)(input * 0.8);
    }  
}
