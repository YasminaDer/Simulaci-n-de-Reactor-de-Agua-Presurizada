package prog2.model;

import java.io.Serializable;

/**
 * Esta clase representa la turbina en la central eléctrica.
 * Implementa la interfaz InComponent.
 * Implementa la interfaz Serializable para permitir su serialización.
 * 
 * @author Yasmina Dermouh y Katerina Lothe
 */
public class Turbina implements InComponent, Serializable {
    
    // Atributo para indicar si la turbina está activada
    private boolean activat;
    
    /**
     * Constructor de la clase Turbina.
     * Inicializa la turbina como desactivada.
     */
    public Turbina() {
        activat = false;
    }
    
    /**
     * Activa la turbina.
     */
    @Override
    public void activa() { 
        this.activat = true; 
    }

    /**
     * Desactiva la turbina.
     */
    @Override
    public void desactiva() { 
        this.activat = false; 
    }

    /**
     * Revisa las incidencias de la turbina y las registra en la página de incidencias.
     * 
     * @param p la página de incidencias en la que se registrarán las incidencias.
     */
    @Override
    public void revisa(PaginaIncidencies p) {
        if (!activat) {
            String descIncidencia = "La turbina no está habilitada.";
            p.afegeixIncidencia(descIncidencia);
        }
    }

    /**
     * Retorna el costo operativo de la turbina.
     * 
     * @return el costo operativo de la turbina.
     */
    @Override
    public float getCostOperatiu() { 
        return !activat ? 0 : 20; 
    }
    
    /**
     * Calcula el output de la turbina basado en la entrada.
     * 
     * @param input los grados del generador de vapor.
     * @return el output de la turbina en unidades de potencia.
     */
    @Override
    public float calculaOutput(float input) {
        // Falta incorporar las incidencias y excepciones
        if(!activat) return 0;
        else if(!activat && input < 100) return 0;
        else return input * 2;
    }   
}
