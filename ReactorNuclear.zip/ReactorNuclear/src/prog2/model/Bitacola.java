/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package prog2.model;

import java.util.ArrayList;
import java.util.List;
import java.io.*;

/**
 * Esta clase representa una bitácora que almacena páginas de bitácora.
 * Implementa la interfaz InBitacola y es serializable.
 * 
 * @autor Yasmina Dermouh y Katerina Lothe
 */
public class Bitacola implements InBitacola, Serializable {
    
    private ArrayList<PaginaBitacola> paginesBitacola;

    /**
     * Constructor de la clase Bitacola.
     * Inicializa una nueva lista de páginas de bitácora.
     */
    public Bitacola() {
        paginesBitacola = new ArrayList<>(); 
    }

    /**
     * Añade una nueva página a la bitácora.
     * 
     * @param p la página de bitácora a añadir.
     */
    @Override
    public void afegeixPagina(PaginaBitacola p) {
        this.paginesBitacola.add(p);
    }

    /**
     * Obtiene una lista de todas las páginas de incidencias en la bitácora.
     * 
     * @return una lista de páginas de incidencias.
     */
    @Override
    public List<PaginaIncidencies> getIncidencies() {
        List<PaginaIncidencies> incidenciesList = new ArrayList<>();

        // Iterar sobre las páginas de la bitácora
        for (PaginaBitacola pagina : paginesBitacola) {
            // Comprobar si la página es una instancia de PaginaIncidencies
            if (pagina instanceof PaginaIncidencies) {
                // Realizar casting y agregar a la lista de incidencias
                incidenciesList.add((PaginaIncidencies) pagina);
            }
        }
        return incidenciesList;
    }  
    
    /**
     * Retorna una representación en forma de cadena de todas las páginas de la bitácora.
     * 
     * @return una cadena con todas las páginas de la bitácora.
     */
    @Override
    public String toString() {
        String paginas = "";
        for (PaginaBitacola pagina : paginesBitacola) {
            paginas += pagina.toString() + "\n";
        }
        return paginas;
    } 
}
