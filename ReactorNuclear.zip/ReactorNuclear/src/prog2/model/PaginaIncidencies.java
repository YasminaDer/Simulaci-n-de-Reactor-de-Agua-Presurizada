package prog2.model;

import java.util.ArrayList;
import java.util.Iterator;
import java.io.Serializable;

/**
 * Esta clase representa una página de incidencias en el sistema de la central eléctrica,
 * extendiendo la funcionalidad de la clase PaginaBitacola.
 * Implementa la interfaz Serializable para permitir su serialización.
 * 
 * @autor Yasmina Dermouh y Katerina Lothe
 */
public class PaginaIncidencies extends PaginaBitacola implements Serializable {
    
    // ArrayList para almacenar descripciones de incidencias
    private ArrayList<String> descripcioIncidencies;
    
    /**
     * Constructor de la clase PaginaIncidencies.
     * 
     * @param dia el día correspondiente a la página de incidencias.
     */
    public PaginaIncidencies(int dia) {
        super(dia);
        this.descripcioIncidencies = new ArrayList<>();
    }
    
    /**
     * Retorna la lista de descripciones de incidencias.
     * 
     * @return la lista de descripciones de incidencias.
     */
    public ArrayList<String> getDescripcio() {
        return descripcioIncidencies;
    }
    
    /**
     * Establece la lista de descripciones de incidencias.
     * 
     * @param descripcioIncidencies la lista de descripciones de incidencias a establecer.
     */
    public void setDescripcio(ArrayList<String> descripcioIncidencies) {
        this.descripcioIncidencies = descripcioIncidencies;
    }
    
    /**
     * Agrega una descripción de incidencia a la lista de descripciones.
     * 
     * @param descIncidencia la descripción de la incidencia a agregar.
     */
    public void afegeixIncidencia(String descIncidencia) {
        this.descripcioIncidencies.add(descIncidencia);
    }
    
    /**
     * Retorna una representación en String de la página de incidencias.
     * 
     * @return una cadena de texto que representa la página de incidencias.
     */
    @Override
    public String toString() {
        StringBuilder descrip = new StringBuilder();
        Iterator<String> itr = descripcioIncidencies.iterator();
        while(itr.hasNext()) {
            String current = itr.next();
            descrip.append("- Descripción Incidencia: ").append(current).append("\n");
        }
        return "# Página de Incidencias\n" +
                "- Día: " + dia + "\n" +
                descrip + "\n";
    }
}
