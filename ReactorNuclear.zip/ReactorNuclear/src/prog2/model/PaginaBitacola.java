/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package prog2.model;

import java.io.Serializable;

/**
 * Esta clase representa una página de bitácora en el sistema de la central eléctrica.
 * Implementa la interfaz Serializable para permitir su serialización.
 * 
 * @autor Yasmina Dermouh y Katerina Lothe
 */
public class PaginaBitacola implements Serializable {

    // Día correspondiente a la página de bitácora
    protected final int dia;

    /**
     * Constructor de la clase PaginaBitacola.
     * 
     * @param dia el día correspondiente a la página de bitácora.
     */
    public PaginaBitacola(int dia) {
        this.dia = dia;
    }
}
