/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package prog2.vista;
/**
 * Una excepción personalizada para manejar errores específicos de la aplicación CentralUB.
 * Extiende la clase Exception de Java para permitir el manejo de excepciones.
 *
 * @author Yasmina Dermouh y Katerina Lothe
 */

public class CentralUBException extends Exception {
    
    /**
     * Constructor que permite crear una instancia de CentralUBException con un mensaje de error específico.
     * 
     * @param message El mensaje que describe la naturaleza del error.
     */
    public CentralUBException(String message) {
        super(message);
    }
}

