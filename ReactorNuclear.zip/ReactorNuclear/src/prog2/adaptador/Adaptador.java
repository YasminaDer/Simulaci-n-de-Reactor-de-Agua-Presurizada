/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package prog2.adaptador;

import java.util.List;
import prog2.model.*;
import java.util.ArrayList;
import prog2.vista.CentralUBException;
import java.io.*;

/**
 * Esta clase actúa como adaptador para la gestión de los datos del sistema.
 * Proporciona métodos para interactuar con el sistema, incluyendo la gestión
 * del reactor, el sistema de refrigeración y la bitácora.
 * 
 * @autor Katerina Lothe y Yasmina Dermouh
 */
public class Adaptador {
    Dades dades;

    /**
     * Constructor de la clase Adaptador.
     * Inicializa una nueva instancia de la clase Dades.
     */
    public Adaptador() {
        dades = new Dades();
    }

    /**
     * Obtiene el día actual.
     * 
     * @return el día actual.
     */
    public int getDia() {
        return dades.getDia();
    }

    /**
     * Obtiene las ganancias acumuladas.
     * 
     * @return las ganancias acumuladas.
     */
    public float getGuanysAcumulats() {
        return dades.getGuanysAcumulats();
    }

    /**
     * Obtiene el valor de inserción de las barras de control.
     * 
     * @return el valor de inserción de las barras.
     */
    public float getInsercioBarres() {
        return dades.getInsercioBarres();
    }

    /**
     * Establece el valor de inserción de las barras de control.
     * 
     * @param insercioBarres el nuevo valor de inserción de las barras.
     * @throws CentralUBException si hay un error al establecer el valor.
     */
    public void setInsercioBarres(float insercioBarres) throws CentralUBException {
        dades.setInsercioBarres(insercioBarres);
    }

    /**
     * Activa el reactor.
     * 
     * @throws CentralUBException si hay un error al activar el reactor.
     */
    public void activaReactor() throws CentralUBException {
        dades.activaReactor();
    }

    /**
     * Desactiva el reactor.
     */
    public void desactivaReactor() {
        dades.desactivaReactor();
    }

    /**
     * Muestra el estado actual del reactor.
     * 
     * @return una cadena con el estado del reactor.
     */
    public String mostraEstatReactor() {
        return "El reactor está " + (dades.mostraReactor().getActivat() ? "activado" : "desactivado") + " y está a " + dades.mostraReactor().getTemp() + " grados Celsius";
    }

    /**
     * Activa una bomba de refrigeración específica.
     * 
     * @param id el identificador de la bomba.
     * @throws CentralUBException si hay un error al activar la bomba.
     */
    public void activaBomba(int id) throws CentralUBException {
        dades.activaBomba(id);
    }

    /**
     * Desactiva una bomba de refrigeración específica.
     * 
     * @param id el identificador de la bomba.
     */
    public void desactivaBomba(int id) {
        dades.desactivaBomba(id);
    }

    /**
     * Obtiene una lista de todas las bombas de refrigeración.
     * 
     * @return una lista de cadenas con la información de cada bomba.
     */
    public String[] getListaBombas() {
        ArrayList<BombaRefrigerant> bombas = dades.mostraSistemaRefrigeracio().getListaBombas();
        String[] listaBombasString = new String[bombas.size()];

        for (int i = 0; i < bombas.size(); i++) {
            listaBombasString[i] = bombas.get(i).toString();
        }

        return listaBombasString;
    }

    /**
     * Muestra el estado actual del sistema de refrigeración.
     * 
     * @return una cadena con el estado del sistema de refrigeración.
     */
    public String mostraEstatSistemaRefrigeracio() {
        return dades.mostraSistemaRefrigeracio().toString();
    }

    /**
     * Muestra el estado actual de la central en base a la demanda de potencia.
     * 
     * @param demandaPotencia la demanda de potencia.
     * @return una cadena con el estado de la central.
     */
    public String mostrarEstatCentral(float demandaPotencia) {
        PaginaEstat paginaEstat = dades.mostraEstat(demandaPotencia);
        return paginaEstat.toString();
    }

    /**
     * Muestra todo el contenido de la bitácora hasta el día actual, incluyendo
     * las páginas de estado, económicas y de incidencias.
     * 
     * @return una cadena con el contenido de la bitácora.
     */
    public String mostrarBitacola() {
        if(!dades.mostraBitacola().toString().equals(""))
            return dades.mostraBitacola().toString();
        else
            return "No hay datos registrados en la bitácora.";
    }

    /**
     * Muestra todas las páginas de incidencias de la bitácora hasta el día actual.
     * 
     * @return una cadena con las incidencias registradas.
     */
    public String mostrarIncidencies() {
        String result = "";
        List<PaginaIncidencies> lista = dades.mostraIncidencies();
        for(PaginaIncidencies current : lista){
            result += current + "\n";
        }
        if(!result.equals(""))
            return result;
        else
            return "No hay incidencias registradas en la bitácora.";
    }

    /**
     * Realiza todas las acciones relacionadas con la finalización de un día.
     * 
     * @param demandaPotencia la demanda de potencia para el día.
     * @return una cadena con el resultado de la finalización del día.
     */
    public String finalitzaDia(float demandaPotencia) {
        return dades.finalitzaDia(demandaPotencia).toString();
    }

    /**
     * Guarda los datos actuales en un archivo.
     * 
     * @param camiDesti la ruta del archivo de destino.
     * @throws CentralUBException si hay un error al guardar los datos.
     */
    public void guardarDades(String camiDesti) throws CentralUBException {
        File fitxer = null;
        FileOutputStream fout = null;
        ObjectOutputStream oos = null;

        try {
            fitxer = new File(camiDesti);
            fout = new FileOutputStream(fitxer);
            oos = new ObjectOutputStream(fout);

            oos.writeObject(this.dades);
        } catch (IOException e) {
            throw new CentralUBException("Error: No se ha podido guardar correctamente.");
        } finally {
            try {
                if (oos != null) {
                    oos.close();
                }
                if (fout != null) {
                    fout.close();
                }
            } catch (IOException e) {
                throw new CentralUBException("Error al cerrar el flujo de salida.");
            }
        }
    }

    /**
     * Carga los datos desde un archivo.
     * 
     * @param camiOrigen la ruta del archivo de origen.
     * @throws CentralUBException si hay un error al cargar los datos.
     */
    public void carregaDades(String camiOrigen) throws CentralUBException {
        FileInputStream fin = null;
        ObjectInputStream ois = null;

        try {
            fin = new FileInputStream(camiOrigen);
            ois = new ObjectInputStream(fin);

            dades = (Dades) ois.readObject();
        } catch (FileNotFoundException e) {
            throw new CentralUBException("No se ha podido cargar.");
        } catch (IOException | ClassNotFoundException e) {
            throw new CentralUBException("Error: No se ha podido recuperar.");
        } finally {
            try {
                if (ois != null) {
                    ois.close();
                }
                if (fin != null) {
                    fin.close();
                }
            } catch (IOException e) {
                throw new CentralUBException("Error al cerrar el flujo de entrada.");
            }
        }
    }
}
